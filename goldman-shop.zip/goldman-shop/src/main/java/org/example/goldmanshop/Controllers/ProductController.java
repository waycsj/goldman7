package org.example.goldmanshop.Controllers;

import org.example.goldmanshop.Dto.ProductDto;
import org.example.goldmanshop.entities.Product;
import org.example.goldmanshop.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

  private ProductService productService;

  @Autowired
  public ProductController(ProductService productService) {
    this.productService = productService;
  }
  //모든 상품 조회
  @GetMapping
  public ResponseEntity<List<Product>> getAllProducts() {
    List<Product> productList = productService.getAllProducts();
    return new ResponseEntity<>(productList, HttpStatus.OK);
  }
  //create Product
  @PostMapping
  public ProductDto createProduct(@RequestBody Product product){
    return null;
  }
}


//import com.thecodereveal.shopease.dto.ProductDto;
//import com.thecodereveal.shopease.entities.Product;
//import com.thecodereveal.shopease.services.ProductService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//    import java.util.List;
//import java.util.UUID;
//
//@RestController
//@RequestMapping("/api/products")
//public class ProductController {
//
//  private ProductService productService;
//
//  @Autowired
//  public ProductController(ProductService productService){
//    this.productService = productService;
//  }
//
//  @GetMapping
//  public ResponseEntity<List<Product>> getAllProducts(@RequestParam(required = false,name = "categoryId",value = "categoryId") UUID categoryId, @RequestParam(required = false,name = "typeId",value = "typeId") UUID typeId ){
//    List<Product> productList = productService.getAllProducts(categoryId,typeId);
//    return new ResponseEntity<>(productList, HttpStatus.OK);
//  }
//
//  //   create Product
//  @PostMapping
//  public ResponseEntity<Product> createProduct(@RequestBody ProductDto productDto){
//    Product product = productService.addProduct(productDto);
//    return new ResponseEntity<>(product,HttpStatus.CREATED);
//  }
//
//
//}