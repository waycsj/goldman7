package org.example.goldmanshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoldmanShopApplication {

  public static void main(String[] args) {
    SpringApplication.run(GoldmanShopApplication.class, args);
  }

}
