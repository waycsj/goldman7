package org.example.goldmanshop.service;

import jakarta.transaction.Transactional;
import org.example.goldmanshop.entities.Product;
import org.example.goldmanshop.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public abstract class ProductServiceImpl implements ProductService {
  @Autowired
  private ProductRepository productRepository;

  @Override
  public Product addProduct(Product product) {
    return null;
  }

  @Override
  public List<Product> getAllProducts() {
    List<Product> products = productRepository.findAll();
    return products;
  }
}
