package org.example.goldmanshop.service;

import org.example.goldmanshop.Dto.ProductDto;
import org.example.goldmanshop.entities.Product;

import java.util.List;
import java.util.UUID;


//뭔지 모름 AI가 작성해줌.
//현재 단계에서 쓰이는 코드가 아님. 작동하나 볼려고.

public interface ProductService {

  public Product addProduct(ProductDto product);
  public List<ProductDto> getProduct(UUID categoryId, UUID typeId);

  ProductDto getProductBySlug(String slug);
  ProductDto getProductById(UUID id);
  ProductDto updateProduct(ProductDto productDto, UUID id);
  Product fetchProductById(UUID id) throws Exception;

  Product addProduct(Product product);

  List<Product> getAllProducts();
}
