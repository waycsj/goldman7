import React from "react";
import { Wishlist } from "../common/Wishlist";
import { AccountIcon } from "../common/AccountIcon";
import { CartIcon } from "../common/CartIcon";
import { Link } from "react-router-dom";
import { NavLink } from "react-router-dom";
import './Navigation.css';

const Navigation = () => {
  return (
    <nav className='flex items-center py-6 px-16 justify-between gap-20 custom-nav'>
      <div className='flex items-center gap-6'>
        {/* Logo */}
        <a className='text-3xl text-black font-bold gap-8' href='/'>ShopEase</a>
      </div>
      <div className='flex flex-wrap items-center gap-10'>
        {/* Nav items */}
        <ul className='flex gap-14 text-gray-600 hover:text-black'>
          <li><NavLink to='/' className={({isActive})=> isActive ? 'active-link':''}>Shop</NavLink></li>
          <li><NavLink to='/men' className={({isActive})=> isActive ? 'active-link':''}>Men</NavLink></li>
          <li><NavLink to='/women' className={({isActive})=> isActive ? 'active-link':''}>Women</NavLink></li>
          <li><NavLink to='/kids' className={({isActive})=> isActive ? 'active-link':''}>Kids</NavLink></li>
        </ul>

      </div>
      <div className='flex justify-center'>
        {/* Search bar */}
        <div className='border rounded flex overflow-hidden'>
          <div className="flex items-center justify-center px-4 border-1">
            <svg className="h-4 w-4 text-grey-dark" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M16.32 14.9l5.39 5.4a1 1 0 0 1-1.42 1.4l-5.38-5.38a8 8 0 1 1 1.41-1.41zM10 16a6 6 0 1 0 0-12 6 6 0 0 0 0 12z"/></svg>
            <input type="text" className="px-4 py-2 outline-none" placeholder="Search"/>
          </div> 

        </div>
      </div>

      <div className='flex flex-wrap items-center gap-4'>
        {/* Action Items - icons */}
        <ul className='flex gap-8 '>
          <li><button ><Wishlist /></button></li>
          <li><button><AccountIcon/></button></li>
          <li><Link to='/cart-items'><CartIcon /></Link></li>
        </ul>
      </div>

    </nav>
  )
}

export default Navigation
//https://github.com/pardeep16/shopEase/blob/e7a5476a6a7d0a3a25cda1f1308ed3e8fd8f7e89/src/components/Navigation/Navigation.jsx
//필터파일 빠진부분 채워넣기+
//cartAction.js이나 cart-item.js 파일이 존재하는지 여부
//키즈페이지 왜 안되는지 알아보기
//메인 페이지가 왜 깨지는지, 디자인도 안 맞아 떻어지는지 알아보기(혹시 파일 맨처음에 붙이는 import문이 잘못되었나 일일히 점검해보자)
//애플리케이션의 루트 컴포넌트를 Provider로 감싸고 Redux store를 전달하기 위해서는 store.js나 store.jsx파일이 필요한가봄+